$(".close_icon,.close_btn").click(function() {
    $(".showpop").fadeOut("slow");
    $(".agree_disabled").fadeOut("slow");
});
alert("Thank you big brother");